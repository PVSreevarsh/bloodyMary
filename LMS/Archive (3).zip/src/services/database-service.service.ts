import { HttpClient } from "@angular/common/http";
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class DatabaseServiceService {

  constructor(
    private _http: HttpClient,
  ) { }

  get(endPoint: string) {
    return new Promise((resolve, reject) => {
      this._http.get(endPoint).subscribe(resp => {
        resolve(resp);
      }, err => {
        reject(this.errorHandling(err, endPoint, {}));
      });
    });
  }

  post(endPoint: string, body = {}) {
    return new Promise((resolve, reject) => {
      this._http.post(endPoint, body).subscribe(resp => {
        resolve(resp);
      }, err => {
        reject(this.errorHandling(err, endPoint, body));
      });
    });
  }

  put(endPoint: string, body = {}) {
    return new Promise((resolve, reject) => {
      this._http.put(endPoint, body).subscribe(resp => {
        resolve(resp);
      }, err => {
        reject(this.errorHandling(err, endPoint, body));
      });
    });
  }

  patch(endPoint: string, body = {}) {
    return new Promise((resolve, reject) => {
      this._http.patch(endPoint, body).subscribe(resp => {
        resolve(resp);
      }, err => {
        reject(this.errorHandling(err, endPoint, body));
      });
    });
  }

  delete(endPoint: string) {
    return new Promise((resolve, reject) => {
      this._http.delete(endPoint).subscribe(resp => {
        resolve(resp);
      }, err => {
        reject(this.errorHandling(err, endPoint, {}));
      });
    });
  }
  private errorHandling(error: any, endPoint: string, payload?: any): any {
    if (error?.error?.code === "UNKNOWN" && error?.error?.message === "read ECONNRESET") {
      // this.commonService.presentToast("DB connection has been reset. Refresh the page/submit the form again", "danger", 3000, 'bottom');
      error.error.status = error.status;
    }
    if (error?.error?.code === "PK_INVALID_TOKEN") {
      error.error.status = error.status;
    }
    if (error?.status === 404 && error?.statusText === "Not Found") {
      error.error = {};
      error.error.code = "PK_API_NOT_FOUND";
      error.error.message = error.message;
      //error.error.status = error.status;
    }
    //error.error.status = error.status;
    // this.commonService.isValidData(error?.error) ? error.error.payload = payload : error.payload = payload;
    // return this.commonService.isValidData(error.error) ? error.error : error;
  }
}
