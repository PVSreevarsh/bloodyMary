import { HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, catchError, tap, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService {

  constructor(
    private router: Router


  ) { }
  intercept(
    httpRequest: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    
    
    let requestHeaders = {
      'Content-Type': 'application/json',
      'X-Source':  'web'
    };

    let url_clone = httpRequest.clone({
      headers: new HttpHeaders(requestHeaders),
    });
    return next.handle(url_clone).pipe(
      tap((httpEvent: HttpEvent<any>) => {
        // console.log(this.user);
        let resToken: string;
        if (httpEvent instanceof HttpErrorResponse && httpEvent.status === 430) {
          return;
        }
      })
    );

  }
}
