import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-bank',
  templateUrl: './bank.page.html',
  styleUrls: ['./bank.page.scss'],
})

export class BankPage implements OnInit {
  public MSMES = [
    {
      name: "sector1",
      risk_classification: "medium",
      value: [
        { name: 'msme1', risk_classification: "medium" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "high" },
        { name: 'msme1', risk_classification: "high" },
      ],
    },
    {
      name: "sector2",
      risk_classification: "low",
      value: [
        { name: 'msme1', risk_classification: "medium" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "high" },
        { name: 'msme1', risk_classification: "high" },
      ],
    },
    {
      name: "sector3",
      risk_classification: "high",
      value: [
        { name: 'msme1', risk_classification: "medium" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "high" },
        { name: 'msme1', risk_classification: "high" },
      ],
    },
  ]

  email: string = "";
  password: string = "";

  constructor(
    private navCtrl: NavController,
  ) { }

  ngOnInit() {
  }

  getData(){
    localStorage.setItem('bank_id', this.email);
  }

  submit(){
    console.log(this.email, this.password);
    this.navCtrl.navigateForward('/bank/bank-dashboard')

  }

}
