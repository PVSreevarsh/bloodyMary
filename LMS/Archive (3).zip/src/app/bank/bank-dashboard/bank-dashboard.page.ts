import { Component, OnInit } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';
import axios from 'axios';
import { DatabaseServiceService } from '../../../services/database-service.service';

@Component({
  selector: 'app-bank-dashboard',
  templateUrl: './bank-dashboard.page.html',
  styleUrls: ['./bank-dashboard.page.scss'],
})
export class BankDashboardPage implements OnInit {
  public MSMES: any = [
    {
      name: "Sector 1",
      risk_classification: "medium",
      value: [
        { name: 'msme1', risk_classification: "medium" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "high" },
        { name: 'msme1', risk_classification: "high" },
      ],
    },
    {
      name: "Sector 2",
      risk_classification: "low",
      value: [
        { name: 'msme1', risk_classification: "medium" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "high" },
        { name: 'msme1', risk_classification: "high" },
      ],
    },
    {
      name: "Sector 2",
      risk_classification: "low",
      value: [
        { name: 'msme1', risk_classification: "medium" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "low" },
        { name: 'msme1', risk_classification: "high" },
        { name: 'msme1', risk_classification: "high" },
      ],
    },
  ]

  public investedAmount = 0.00;
  public isModalOpen = false;
  selectedSector: number | undefined;
  bankID: number = 1;
  amount: any;
  bank: any = {total_amount : 100000,
    values:[
      {sector_name: "Textiles", amount: 20000},
      {sector_name: "Manufacturing", amount: 10000},
      {sector_name: "Hotel and restaurants", amount: 25000},
    ]
  };

  constructor(
    private navCtrl: NavController,
    private toastCtrl: ToastController,
  ) { }

  ngOnInit() {
    this.bankID = localStorage.getItem('bank_id') as unknown as number;

    this.getBankSectorDetails();
  }

  async getBankDetails() {
    var config = {
      method: 'get',
      url: 'https://honestly-perfect-skink.ngrok-free.app/bankLanding/',
      headers: {
        "Content-Type": "application/json",
        // "Access-Control-Allow-Origin": "*", 
        'ngrok-skip-browser-warning': 'true',
      }
    };

    const response: any = await axios(config)
      .then(function (response) {
        console.log(response);
        return response.data as any
      })
      .catch(function (error) {
        console.log(error);
      });
    console.log(this.MSMES)
    this.MSMES[0].name = response.data[0].name;
    this.MSMES[0].total_ask = response.data[0].total_ask;
    this.MSMES[0].total_amount = response.data[0].total_amount;
    this.MSMES[1].name = response.data[1].name;
    this.MSMES[1].total_ask = response.data[1].total_ask;
    this.MSMES[1].total_amount = response.data[1].total_amount;
    this.MSMES[2].name = response.data[2].name;
    this.MSMES[2].total_ask = response.data[2].total_ask;
    this.MSMES[2].total_amount = response.data[2].total_amount;
    this.investedAmount = Number(response.data[0].total_amount) + Number(response.data[1].total_amount) + Number(response.data[2].total_amount)
    console.log(this.MSMES)
  }

  async getBankSectorDetails() {
    var config = {
      method: 'get',
      url: 'https://honestly-perfect-skink.ngrok-free.app/bankLanding/',
      headers: {
        "Content-Type": "application/json",
        // "Access-Control-Allow-Origin": "*", 
        'ngrok-skip-browser-warning': 'true',
      }
    };

    const response: any = await axios(config)
      .then(function (response) {
        console.log(response);
        return response.data as any
      })
      .catch(function (error) {
        console.log(error);
      });
    console.log(this.MSMES)
    this.MSMES[0].name = response.data[0].name;
    this.MSMES[0].total_ask = response.data[0].total_ask;
    this.MSMES[0].total_amount = response.data[0].total_amount;
    this.MSMES[1].name = response.data[1].name;
    this.MSMES[1].total_ask = response.data[1].total_ask;
    this.MSMES[1].total_amount = response.data[1].total_amount;
    this.MSMES[2].name = response.data[2].name;
    this.MSMES[2].total_ask = response.data[2].total_ask;
    this.MSMES[2].total_amount = response.data[2].total_amount;
    this.investedAmount = Number(response.data[0].total_amount) + Number(response.data[1].total_amount) + Number(response.data[2].total_amount)
    console.log(this.MSMES)
  }

  logout() {
    this.navCtrl.navigateRoot('/home')
  }

  setOpen(flag: boolean, index?: number) {
    this.isModalOpen = !this.isModalOpen;
    console.log(index || 0 + 2)
    this.selectedSector = index || 0 + 3;
  }

  async investintoSector() {
    var data = JSON.stringify({
      "bank": 4,
      "sector": 5,
      "amount": 500
    });

    var config = {
      method: 'post',
      url: 'https://honestly-perfect-skink.ngrok-free.app/createInvestment/',
      headers: {
        'Content-Type': 'application/json'
      },
      data: data
    };
    try {
      let response = await axios(config);
      // response.data;
      this.presentToast('Investment Successful', 'success', 2000, 'bottom');
      this.getBankSectorDetails();
    } catch (err) {
      this.presentToast('Investment is more than ask.', 'danger', 2000, 'bottom')
      this.getBankSectorDetails()
    }
  }

  presentToast(
    message: string,
    color = 'primary',
    duration = 3000,
    position: any
  ) {
    this.isModalOpen = !this.isModalOpen;
    this.toastCtrl
      .create({
        message,
        duration,
        position: position,
        color,
        keyboardClose: true,
        cssClass: 'toastCss',
      })
      .then((toast: HTMLIonToastElement) => toast.present());
  }

}
