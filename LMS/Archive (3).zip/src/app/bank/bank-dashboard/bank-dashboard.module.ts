import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BankDashboardPageRoutingModule } from './bank-dashboard-routing.module';

import { BankDashboardPage } from './bank-dashboard.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BankDashboardPageRoutingModule
  ],
  declarations: [BankDashboardPage]
})
export class BankDashboardPageModule {}
