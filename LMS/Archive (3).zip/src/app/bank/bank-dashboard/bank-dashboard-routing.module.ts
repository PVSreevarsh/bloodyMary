import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BankDashboardPage } from './bank-dashboard.page';

const routes: Routes = [
  {
    path: '',
    component: BankDashboardPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BankDashboardPageRoutingModule {}
