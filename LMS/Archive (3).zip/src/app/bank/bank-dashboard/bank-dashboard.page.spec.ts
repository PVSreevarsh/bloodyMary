import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BankDashboardPage } from './bank-dashboard.page';

describe('BankDashboardPage', () => {
  let component: BankDashboardPage;
  let fixture: ComponentFixture<BankDashboardPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(BankDashboardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
