import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BankPage } from './bank.page';

const routes: Routes = [
  {
    path: '',
    component: BankPage
  },
  {
    path: 'bank-dashboard',
    loadChildren: () => import('./bank-dashboard/bank-dashboard.module').then( m => m.BankDashboardPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BankPageRoutingModule {}
