import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(
    private navCtrl: NavController,
  ) { }


  navTo(path: string) {
    console.log(path)
    if (path === "BANK")
      this.navCtrl.navigateForward('/bank')
    else
      this.navCtrl.navigateForward('/msme')

  }

}
