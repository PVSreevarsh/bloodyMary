import { Component, OnInit } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';
import axios from 'axios';

@Component({
  selector: 'app-msme-dashboard',
  templateUrl: './msme-dashboard.page.html',
  styleUrls: ['./msme-dashboard.page.scss'],
})
export class MsmeDashboardPage implements OnInit {

  public response: any =
    {
      "sector": 1,
      "askamt": 200000,
      "givenamt": 0,
      "name": "Habibi",
      "label": null,
      "gstn": "12348jdkdfvb",
      "amtpaid": 0,
      "phoneNumber": "47834934784",
      "sector_name": ""
    };


  pendingAmt = 0;

  constructor(
    private navCtrl: NavController,
    private toastCtrl: ToastController,



  ) { }

  ngOnInit() {

    this.pendingAmt = 0;

    this.getMSMEData();
  }

  async getMSMEData() {
    var data = JSON.stringify({
      "gstn": localStorage.getItem('gstn')
    });

    var config = {
      method: 'post',
      url: 'https://honestly-perfect-skink.ngrok-free.app/showMSME/',
      headers: {
        "Content-Type": "application/json",
        // "Access-Control-Allow-Origin": "*",
        'ngrok-skip-browser-warning': 'true',
      },
      data: data
    };

    const response = await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        return response.data;
      })
      .catch(function (error) {
        console.log(error);
      });
    this.response = response;
    this.pendingAmt = Math.abs(this.response.givenamt - this.response.amtpaid);
  }

  logout() {
    this.navCtrl.navigateRoot('/home');
  }

  presentToast(
    message: string,
    color = 'primary',
    duration = 3000,
    position: any
  ) {

    this.response.pendingAmt -= this.pendingAmt;
    this.toastCtrl
      .create({
        message,
        duration,
        position: position,
        color,
        keyboardClose: true,
        cssClass: 'toastCss',
      })
      .then((toast: HTMLIonToastElement) => toast.present());
    this.pendingAmt = 0
  }
}
