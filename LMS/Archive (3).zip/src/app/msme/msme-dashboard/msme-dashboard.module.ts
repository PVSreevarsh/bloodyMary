import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MsmeDashboardPageRoutingModule } from './msme-dashboard-routing.module';

import { MsmeDashboardPage } from './msme-dashboard.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MsmeDashboardPageRoutingModule
  ],
  declarations: [MsmeDashboardPage]
})
export class MsmeDashboardPageModule {}
