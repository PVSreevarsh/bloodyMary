import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MsmeDashboardPage } from './msme-dashboard.page';

const routes: Routes = [
  {
    path: '',
    component: MsmeDashboardPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MsmeDashboardPageRoutingModule {}
