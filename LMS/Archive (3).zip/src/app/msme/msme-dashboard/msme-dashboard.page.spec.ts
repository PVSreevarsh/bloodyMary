import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MsmeDashboardPage } from './msme-dashboard.page';

describe('MsmeDashboardPage', () => {
  let component: MsmeDashboardPage;
  let fixture: ComponentFixture<MsmeDashboardPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MsmeDashboardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
