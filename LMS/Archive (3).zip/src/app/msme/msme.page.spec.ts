import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MsmePage } from './msme.page';

describe('MsmePage', () => {
  let component: MsmePage;
  let fixture: ComponentFixture<MsmePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MsmePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
