import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MsmeRegisterPage } from './msme-register.page';

describe('MsmeRegisterPage', () => {
  let component: MsmeRegisterPage;
  let fixture: ComponentFixture<MsmeRegisterPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MsmeRegisterPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
