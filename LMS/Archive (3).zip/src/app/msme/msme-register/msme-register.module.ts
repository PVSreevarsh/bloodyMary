import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MsmeRegisterPageRoutingModule } from './msme-register-routing.module';

import { MsmeRegisterPage } from './msme-register.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MsmeRegisterPageRoutingModule
  ],
  declarations: [MsmeRegisterPage]
})
export class MsmeRegisterPageModule {}
