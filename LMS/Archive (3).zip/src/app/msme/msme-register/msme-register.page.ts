import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import axios from 'axios';

@Component({
  selector: 'app-msme-register',
  templateUrl: './msme-register.page.html',
  styleUrls: ['./msme-register.page.scss'],
})
export class MsmeRegisterPage implements OnInit {

  registrationFlag = false;
  name: any;
  gstn: any;
  sel_sector: any = [];
  askamt: any;
  phoneNumber: any;
  sectors: any = [{id:1, name:"Textiles"}, {id:2, name:"Manufacturing"}];

  constructor(
    private navCtrl: NavController,
  ) { }

  ngOnInit() {
    this.getSectors()
  }

  async register() {
    console.log(this.sel_sector)
    var data = JSON.stringify({
      "sector": this.sel_sector,
      "askamt": Number(this.askamt),
      "name": this.name,
      "gstn": this.gstn,
      "phoneNumber": this.phoneNumber
    });

    var config = {
      method: 'post',
      url: 'https://honestly-perfect-skink.ngrok-free.app/registerMSME/',
      headers: {
        "Content-Type": "application/json",
        // "Access-Control-Allow-Origin": "*", 
        'ngrok-skip-browser-warning': 'true',
      },
      data: data
    };

    const response = await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        return response.data
      })
      .catch(function (error) {
        console.log(error);
      });
    console.log(response)
  }

  async getSectors() {
    var config = {
      method: 'get',
      url: 'https://honestly-perfect-skink.ngrok-free.app/bankLanding/',
      headers: {
        "Content-Type": "application/json",
        // "Access-Control-Allow-Origin": "*", 
        'ngrok-skip-browser-warning': 'true',
      },
    };
    
    const response = await axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
      return response.data
    })
    .catch(function (error) {
      console.log(error);
    });
    console.log(response.data)
    this.sectors = response.data;
  }

  submit() {
    this.register()
    this.registrationFlag = true;

  }

  startVetting(){
    localStorage.setItem('gstn', this.gstn);
    setTimeout(() => {
      this.navCtrl.navigateForward('/msme/msme-dashboard')
    }, 5000);
  }
}
