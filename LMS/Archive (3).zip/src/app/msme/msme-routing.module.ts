import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MsmePage } from './msme.page';

const routes: Routes = [
  {
    path: '',
    component: MsmePage
  },
  {
    path: 'msme-register',
    loadChildren: () => import('./msme-register/msme-register.module').then( m => m.MsmeRegisterPageModule)
  },
  {
    path: 'msme-dashboard',
    loadChildren: () => import('./msme-dashboard/msme-dashboard.module').then( m => m.MsmeDashboardPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MsmePageRoutingModule {}
