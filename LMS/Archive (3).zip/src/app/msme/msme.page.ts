import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-msme',
  templateUrl: './msme.page.html',
  styleUrls: ['./msme.page.scss'],
})
export class MsmePage implements OnInit {
  email: string = "";
  password: string = '';

  constructor(
    private navCtrl: NavController,
  ) { }

  ngOnInit() {
  }

  submit(){
    console.log(this.email, this.password);
    this.navCtrl.navigateForward('/msme/msme-dashboard');
  }

  register(){
    this.navCtrl.navigateForward('/msme/msme-register')
  }
}
